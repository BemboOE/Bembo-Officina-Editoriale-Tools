# Titolo dell'elaborato: eventuale *testo corsivo* presente

# Autori

```
Nome e cognome primo autore
posizione nell'organizzazione
email istituzionale
istituzione
```
```
Nome e cognome secondo autore
posizione nell'organizzazione
email istituzionale
istituzione
```

# Abstract

Lorem ipsum dolor sit amet, *consectetur adipiscing elit*. Phasellus nec varius lorem. Donec sed mauris odio. Mauris sed lorem eget diam tincidunt aliquam. Suspendisse mattis elit nibh, quis vulputate odio rutrum dignissim. Quisque porttitor nisl diam, et *lacinia massa ultricies* id. Integer laoreet fermentum quam, ac rhoncus turpis dapibus vitae. Maecenas scelerisque nibh tortor. Nullam imperdiet scelerisque euismod. Praesent imperdiet dolor sem. Sed vitae turpis at elit sodales eleifend sollicitudin sit amet arcu. Aliquam vulputate porta imperdiet. Donec quis accumsan dui. Cras egestas nulla pharetra mattis lobortis.

# Parole chiave
parola chiave 1, parola chiave 2, parola chiave 3, parola chiave 4, parola chiave 5

# Attribuzioni
I paragrafi *n* e *n* sono attribuiti ad emtrambe/i le/gli autrici/autori; il paragrafo *n* è attribuito a/alla primo/a autore/autrice; il paragrafo *n* è attribuito a/alla primo/a autore/autrice.