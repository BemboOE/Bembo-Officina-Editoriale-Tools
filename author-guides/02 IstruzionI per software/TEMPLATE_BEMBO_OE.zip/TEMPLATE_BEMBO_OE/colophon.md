<!-- MODIFICARE CON INFORMAZIONI AUTORE -->
<p class="autore">
Nome e cognome primo autore
posizione nell'organizzazione
email istituzionale
istituzione
</p>

<!-- NON MODIFICARE -->
<p class='attribuzioni'>
Comitato scientifico: Maria Chiara Tosi (Presidente), Marco Bertozzi, Massimo Bulgarelli, Antonella Cecchi, Pippo Ciorra, Luca Monica, Anna Marson, Fabio Peron, Raimonda Riccini
&nbsp;
Direttore editoriale: Raimonda Riccini
&nbsp;
Coordinamento redazionale: Rosa Chiesa, Maddalena Dalla Mura
&nbsp;
Redazione: Matteo Basso, Marco Capponi, Olimpia Mazzarella, Michela Pace, Claudia Pirina, Francesco Zucconi
&nbsp;
Art direction: Luciano Perondi
&nbsp;
Progetto grafico: Emilio Patuzzo
&nbsp;
Sviluppo web: Giovanni Borga
&nbsp;
Automazione processi di impaginazione: Roberto Arista, Giampiero Dalai, Federico Santarini
</p>

<p class='attribuzioni'>
Tutti i saggi sono pubblicati con la licenza Attribuzione – Non commerciale – Condividi allo stesso modo 4.0 Internazionale (CC BY-SA 4.0)
Le figure a supporto dei saggi presenti in questo libro rispondono alla pratica del fair use (copyright act 17 USC 107 e art 70 della legge n. 633/1941) essendo finalizzate al commento storico critico e all’insegnamento.</p>

<p class="keywords">
2021, Venezia
</p>

<p class='attribuzioni'>
ISBN: 000000000000
</p>

<!-- MODIFICARE CON INFORMAZIONI AUTORE -->

<p class="titolo-frontespizio">
TITOLO LIBRO IN CAPS LOCK
</p>

<p class="sottotitolo-frontespizio">
Eventuale Sottotitolo.
</p>

<p class='sottotitolo-frontespizio'>
Nome e cognome primo autore
</p>

<!-- NON MODIFICARE -->
<p class='sottotitolo-frontespizio'>
Bembo Officina Editoriale
</p>